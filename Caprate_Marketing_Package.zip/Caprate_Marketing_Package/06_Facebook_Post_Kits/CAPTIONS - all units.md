# Caprate — Facebook Post Captions

One ready-to-post caption per available unit. Attach the photos (and/or the branded graphic) from that unit's folder. Fair-housing note: these state what you *accept*, not who should apply — keep it that way in comments too.

---

## 5110 Nelson Ave

🏡 NOW AVAILABLE — 5110 Nelson Ave (Arlington, 21215)

2 Bed / 1 Bath · Voucher-friendly — we welcome Housing Choice Vouchers (HCV / Section 8) and HUD-VASH.

Fully renovated end-of-row rowhome — stainless & granite kitchen, LVP floors, finished basement with in-unit washer & dryer, and a private fenced yard.

We work directly with case managers for fast, responsive RTA processing — no extra fees for voucher holders.

📞 Schedule a showing or refer a client: (410) 415-3142
📧 leasing@capratepropertymgmt.com

#Baltimore #Section8 #HousingChoiceVoucher #HUDVASH #BaltimoreRentals #VoucherFriendly

---

## 629 Dumbarton Ave, Unit D

🏡 NOW AVAILABLE — 629 Dumbarton Ave, Unit D (Original Northwood, 21218)

1 Bed / 1 Bath · Voucher-friendly — we welcome Housing Choice Vouchers (HCV / Section 8) and HUD-VASH.

Renovated apartment in a quiet Northeast Baltimore building, close to the VA and major routes.

We work directly with case managers for fast, responsive RTA processing — no extra fees for voucher holders.

📞 Schedule a showing or refer a client: (410) 415-3142
📧 leasing@capratepropertymgmt.com

#Baltimore #Section8 #HousingChoiceVoucher #HUDVASH #BaltimoreRentals #VoucherFriendly

---

## 1922 Griffis Ave

🏡 NOW AVAILABLE — 1922 Griffis Ave (Rosemont, 21216)

Contact for bed/bath · Voucher-friendly — we welcome Housing Choice Vouchers (HCV / Section 8) and HUD-VASH.

Freshly renovated rowhome — clean, bright finishes and move-in ready.

We work directly with case managers for fast, responsive RTA processing — no extra fees for voucher holders.

📞 Schedule a showing or refer a client: (410) 415-3142
📧 leasing@capratepropertymgmt.com

#Baltimore #Section8 #HousingChoiceVoucher #HUDVASH #BaltimoreRentals #VoucherFriendly

---

## 511 E 43rd St, Unit 3A

🏡 NOW AVAILABLE — 511 E 43rd St, Unit 3A (Waverly / Pen Lucy, 21212)

3 Bed / 1 Bath · Voucher-friendly — we welcome Housing Choice Vouchers (HCV / Section 8) and HUD-VASH.

Spacious 3-bedroom with in-unit washer & dryer, near Loyola, Notre Dame & JHU.

We work directly with case managers for fast, responsive RTA processing — no extra fees for voucher holders.

📞 Schedule a showing or refer a client: (410) 415-3142
📧 leasing@capratepropertymgmt.com

#Baltimore #Section8 #HousingChoiceVoucher #HUDVASH #BaltimoreRentals #VoucherFriendly

---

## 1700 Braddish Ave, Unit A

🏡 NOW AVAILABLE — 1700 Braddish Ave, Unit A (Rosemont, 21216)

Contact for bed/bath · Voucher-friendly — we welcome Housing Choice Vouchers (HCV / Section 8) and HUD-VASH.

Renovated apartment with fresh finishes throughout.

We work directly with case managers for fast, responsive RTA processing — no extra fees for voucher holders.

📞 Schedule a showing or refer a client: (410) 415-3142
📧 leasing@capratepropertymgmt.com

#Baltimore #Section8 #HousingChoiceVoucher #HUDVASH #BaltimoreRentals #VoucherFriendly

---

## 2513 Liberty Heights Ave, Basement

🏡 NOW AVAILABLE — 2513 Liberty Heights Ave, Basement (Forest Park, 21215)

1 Bed / 1 Bath · Voucher-friendly — we welcome Housing Choice Vouchers (HCV / Section 8) and HUD-VASH.

Renovated basement apartment with a private entrance in a multifamily building.

We work directly with case managers for fast, responsive RTA processing — no extra fees for voucher holders.

📞 Schedule a showing or refer a client: (410) 415-3142
📧 leasing@capratepropertymgmt.com

#Baltimore #Section8 #HousingChoiceVoucher #HUDVASH #BaltimoreRentals #VoucherFriendly

---

## 2905 Garrison Blvd, Unit C

🏡 NOW AVAILABLE — 2905 Garrison Blvd, Unit C (Garwyn Oaks, 21216)

1 Bed / 1 Bath · Voucher-friendly — we welcome Housing Choice Vouchers (HCV / Section 8) and HUD-VASH.

Renovated apartment with granite counters, stainless steel, and on-site laundry.

We work directly with case managers for fast, responsive RTA processing — no extra fees for voucher holders.

📞 Schedule a showing or refer a client: (410) 415-3142
📧 leasing@capratepropertymgmt.com

#Baltimore #Section8 #HousingChoiceVoucher #HUDVASH #BaltimoreRentals #VoucherFriendly

---

## 2910 Garrison Blvd, Unit 2T

🏡 NOW AVAILABLE — 2910 Garrison Blvd, Unit 2T (Garwyn Oaks, 21216)

2 Bed / 1 Bath · Voucher-friendly — we welcome Housing Choice Vouchers (HCV / Section 8) and HUD-VASH.

Renovated apartment with in-unit washer & dryer and a granite & stainless kitchen.

We work directly with case managers for fast, responsive RTA processing — no extra fees for voucher holders.

📞 Schedule a showing or refer a client: (410) 415-3142
📧 leasing@capratepropertymgmt.com

#Baltimore #Section8 #HousingChoiceVoucher #HUDVASH #BaltimoreRentals #VoucherFriendly

---

## 2910 Garrison Blvd, Unit 5T

🏡 NOW AVAILABLE — 2910 Garrison Blvd, Unit 5T (Garwyn Oaks, 21216)

2 Bed / 1 Bath · Voucher-friendly — we welcome Housing Choice Vouchers (HCV / Section 8) and HUD-VASH.

ACCESSIBLE unit — ramped entry and walk-in shower with grab bars. Renovated throughout.

We work directly with case managers for fast, responsive RTA processing — no extra fees for voucher holders.

📞 Schedule a showing or refer a client: (410) 415-3142
📧 leasing@capratepropertymgmt.com

#Baltimore #Section8 #HousingChoiceVoucher #HUDVASH #BaltimoreRentals #VoucherFriendly

---

## 4911 Nelson Ave 📸 (photos coming — use the branded graphic for now)

🏡 NOW AVAILABLE — 4911 Nelson Ave (Arlington, 21215)

Contact for details · Voucher-friendly — we welcome Housing Choice Vouchers (HCV / Section 8) and HUD-VASH.

Voucher-friendly rowhome in Arlington. Photos coming soon!

We work directly with case managers for fast, responsive RTA processing — no extra fees for voucher holders.

📞 Schedule a showing or refer a client: (410) 415-3142
📧 leasing@capratepropertymgmt.com

#Baltimore #Section8 #HousingChoiceVoucher #HUDVASH #BaltimoreRentals #VoucherFriendly

---

## 724 N Edgewood St, Unit B 📸 (photos coming — use the branded graphic for now)

🏡 NOW AVAILABLE — 724 N Edgewood St, Unit B (East Baltimore, 21205)

Contact for details · Voucher-friendly — we welcome Housing Choice Vouchers (HCV / Section 8) and HUD-VASH.

Voucher-friendly apartment. Photos coming soon!

We work directly with case managers for fast, responsive RTA processing — no extra fees for voucher holders.

📞 Schedule a showing or refer a client: (410) 415-3142
📧 leasing@capratepropertymgmt.com

#Baltimore #Section8 #HousingChoiceVoucher #HUDVASH #BaltimoreRentals #VoucherFriendly

---

## 2603 Boone St 📸 (photos coming — use the branded graphic for now)

🏡 NOW AVAILABLE — 2603 Boone St (Better Waverly, 21218)

Contact for details · Voucher-friendly — we welcome Housing Choice Vouchers (HCV / Section 8) and HUD-VASH.

Voucher-friendly rowhome in Better Waverly. Photos coming soon!

We work directly with case managers for fast, responsive RTA processing — no extra fees for voucher holders.

📞 Schedule a showing or refer a client: (410) 415-3142
📧 leasing@capratepropertymgmt.com

#Baltimore #Section8 #HousingChoiceVoucher #HUDVASH #BaltimoreRentals #VoucherFriendly

---

## 3512 Clifton Ave, Unit 3 📸 (photos coming — use the branded graphic for now)

🏡 NOW AVAILABLE — 3512 Clifton Ave, Unit 3 (Walbrook, 21216)

Contact for details · Voucher-friendly — we welcome Housing Choice Vouchers (HCV / Section 8) and HUD-VASH.

Voucher-friendly apartment. Photos coming soon!

We work directly with case managers for fast, responsive RTA processing — no extra fees for voucher holders.

📞 Schedule a showing or refer a client: (410) 415-3142
📧 leasing@capratepropertymgmt.com

#Baltimore #Section8 #HousingChoiceVoucher #HUDVASH #BaltimoreRentals #VoucherFriendly

---

## 2924 Garrison Blvd, Unit B 📸 (photos coming — use the branded graphic for now)

🏡 NOW AVAILABLE — 2924 Garrison Blvd, Unit B (Garwyn Oaks, 21216)

Contact for details · Voucher-friendly — we welcome Housing Choice Vouchers (HCV / Section 8) and HUD-VASH.

Voucher-friendly apartment in Garwyn Oaks. Photos coming soon!

We work directly with case managers for fast, responsive RTA processing — no extra fees for voucher holders.

📞 Schedule a showing or refer a client: (410) 415-3142
📧 leasing@capratepropertymgmt.com

#Baltimore #Section8 #HousingChoiceVoucher #HUDVASH #BaltimoreRentals #VoucherFriendly

---

## 2945 Allendale Rd, Unit B 📸 (photos coming — use the branded graphic for now)

🏡 NOW AVAILABLE — 2945 Allendale Rd, Unit B (Garwyn Oaks, 21216)

Contact for details · Voucher-friendly — we welcome Housing Choice Vouchers (HCV / Section 8) and HUD-VASH.

Voucher-friendly apartment in Garwyn Oaks. Photos coming soon!

We work directly with case managers for fast, responsive RTA processing — no extra fees for voucher holders.

📞 Schedule a showing or refer a client: (410) 415-3142
📧 leasing@capratepropertymgmt.com

#Baltimore #Section8 #HousingChoiceVoucher #HUDVASH #BaltimoreRentals #VoucherFriendly

---

## 2933 Allendale Rd, Unit T 📸 (photos coming — use the branded graphic for now)

🏡 NOW AVAILABLE — 2933 Allendale Rd, Unit T (Garwyn Oaks, 21216)

2 Bed / 1 Bath · Voucher-friendly — we welcome Housing Choice Vouchers (HCV / Section 8) and HUD-VASH.

Renovated apartment with on-site laundry & parking. Photos coming soon!

We work directly with case managers for fast, responsive RTA processing — no extra fees for voucher holders.

📞 Schedule a showing or refer a client: (410) 415-3142
📧 leasing@capratepropertymgmt.com

#Baltimore #Section8 #HousingChoiceVoucher #HUDVASH #BaltimoreRentals #VoucherFriendly

---
