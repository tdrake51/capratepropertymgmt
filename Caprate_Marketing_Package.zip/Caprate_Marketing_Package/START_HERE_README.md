# Caprate Property Management — Marketing Package
### Everything for finding tenants in Baltimore City · 2026

This package contains the full online marketing system for Caprate's voucher-friendly rentals — strategy, website pages, tenant and caseworker content, and the property listings. It's organized so you can pick up any piece and use it.

---

## What's in each folder

**01_Strategy_Plans/**
The two marketing strategy documents. Start here.
- *Caprate_Online_Marketing_Plan* — the full four-channel plan (AffordableHousing.com, agency network, Facebook, paid sites) with sequencing and metrics.
- *Caprate_Marketing_Plan_Caseworkers_and_Tenants* — the focused two-track plan: reaching caseworkers, and empowering individual voucher holders to take the lead in their search.

**02_Website/**
The website pages (HTML — open in any browser; deploy to capratepropertymgmt.com).
- *caprate_landing* — the main landing page. Links to the voucher guide in its nav.
- *caprate_voucher_guide* — the "Voucher Holder's Guide" resource page. Links back to the landing page.
- *README* — deployment instructions (hosting, Namecheap DNS, editing the common things). **Keep these HTML files together** — they link to each other by filename.

**03_Tenant_Content/**
Content that reaches and empowers individual renters.
- *Caprate_Tenant_Education_Series* — six ready-to-publish posts (post one a week on Facebook).
- *Caprate_Blog_Finding_Right_Apartment_Baltimore* — the anchor blog post.

**04_Caseworker_Content/**
Content for the professional referral audience.
- *Caprate_Caseworker_LinkedIn_Copy* — LinkedIn profile copy, ready-to-post updates, and a reusable "intro to a new agency" message.

**05_Listings/**
The actual property inventory and listing materials.
- *Caprate_Marketplace_Listings* — Facebook Marketplace listings for all units (post from Yudah's profile on behalf of Caprate). **Rents are estimates — verify before posting.**
- *Caprate_Photo_Pull_Workbook* — reference sheet: every unit, photo-source links, and flags for which online photos are the exact unit vs. a neighbor.
- *Caprate_Available_Units_MD* — the master available-units sheet.
- *Caprate_Availability_Flyer_MD_July2026* — the printable/emailable availability flyer.

**06_Facebook_Post_Kits/**
Per-unit folders, each with real interior photos + a branded graphic + captions. "WITH PHOTOS" folders are ready to post; "PHOTOS TO COME" folders need pictures (see the photo-pull workbook).

---

## Suggested first moves

1. **Read the two strategy plans** (folder 01) so the pieces make sense together.
2. **List photo-ready units on AffordableHousing.com** — free, and where your exact tenant looks first.
3. **Keep the weekly caseworker email going**, and set up the LinkedIn presence (folder 04).
4. **Start the tenant education series** on Facebook — one post a week (folder 03).
5. **Post Marketplace listings** from Yudah's profile, leading with photo-ready units, in batches (folder 05).
6. **Deploy the website** (folder 02) so both audiences find a professional presence.
7. **Finish the photo run** for the 7 units without pictures — this gates the effectiveness of everything.

---

## Standing reminders

- **Fair housing on every public channel:** state what you *accept* (vouchers), never who should apply.
- **The tenant content educates — it doesn't give official determinations.** Always point people to their caseworker or HABC for their specific voucher.
- **Rents in the Marketplace listings are estimates.** Verify before posting.
- **Verify the flagged units** before posting: 2905 Garrison C (photos + bed count), 629 Dumbarton D (bed count), 511 E 43rd 3A (config).
- **Responsiveness is the whole thing** — all of this drives inquiries; answer them fast and warm.

---

*Caprate Property Management · Baltimore City, MD · (410) 415-3142 · leasing@capratepropertymgmt.com · Equal Housing Opportunity*
