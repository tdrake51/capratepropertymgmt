# Caprate — Caseworker & LinkedIn Copy (Track 1)
### Reaching the professionals who place tenants

**How to use this:** Track 1 is about credibility and being easy to refer to — not advertising. This file gives you (1) LinkedIn profile copy for Caprate/Terry Drake, (2) a set of ready-to-post LinkedIn updates aimed at caseworkers and agency staff, and (3) a short reusable "intro to a new agency" message. Keep the tone professional, warm, and partnership-focused. These are written to make an agency contact think: *this is someone I can send a client to.*

---

## 1. LinkedIn Profile Copy

### Headline (the one-liner under your name)
> Voucher-Friendly Housing in Baltimore City | Partnering with Case Managers & Agencies for Fast, Reliable Placements | Caprate Property Management

### About / Summary section
> Caprate Property Management provides renovated, move-in-ready rental homes across Baltimore City — and we specialize in doing voucher-friendly housing the right way.
>
> We work directly with case managers, housing navigators, and placing agencies to make placements fast and predictable. We welcome Housing Choice Vouchers (HCV / Section 8) and HUD-VASH, we're responsive to RTA and inspection scheduling, and we keep clear role boundaries: we provide the unit and coordinate the housing side, so your team can stay focused on the wraparound services and the client relationship.
>
> If you place clients into housing in Baltimore and you're tired of landlords who say "no vouchers" or disappear during the RTA process, let's talk. We'd rather be the reliable partner you can count on than just another listing.
>
> 📞 (410) 415-3142 · ✉️ leasing@capratepropertymgmt.com

### Experience entry (for Terry Drake)
> **Owner / Operator — Caprate Property Management**
> Baltimore, MD
> Voucher-friendly residential rental management and housing placement across Baltimore City. Specializing in HCV/Section 8 and HUD-VASH housing, agency partnerships, and responsive RTA processing. Focused on providing safe, renovated, move-in-ready homes and being a dependable placement partner for Baltimore's housing and behavioral-health agencies.

---

## 2. Ready-to-Post LinkedIn Updates

Post these occasionally (once or twice a week is plenty). They're written for the professional audience — caseworkers, navigators, agency staff — not for tenants. Photos of renovated units help here too.

### Post A — Introduce the partnership approach
> A lot of case managers tell us the same thing: the hardest part of placing a client isn't finding *a* unit — it's finding a landlord who actually welcomes vouchers and moves quickly through RTA and inspection.
>
> That's the gap Caprate is built to fill. We keep renovated, move-in-ready units across Baltimore City, we welcome HCV/Section 8 and HUD-VASH, and we treat case managers as partners — clear roles, fast paperwork, straight answers.
>
> If you place clients in Baltimore, I'd genuinely like to be on your short list. Reach out anytime: (410) 415-3142.

### Post B — Highlight an accessible unit (when available)
> Accessibility matters, and it's often the hardest thing to find. We currently have an accessible unit available in Baltimore — ramped entry, walk-in shower with grab bars, fully renovated, and voucher-friendly.
>
> If you're working with a client who needs an accessible, move-in-ready home, let's connect. (410) 415-3142.

### Post C — The "we make RTA easy" angle
> For the case managers in my network: one thing we hear over and over is how long the RTA and inspection process can drag when a landlord isn't responsive.
>
> At Caprate, that's the part we work hardest to get right. We keep units inspection-ready, we turn paperwork around quickly, and we stay reachable throughout. Your client's voucher clock is ticking — we don't want to be the reason it runs out.
>
> Voucher-friendly units across Baltimore City. (410) 415-3142.

### Post D — Role clarity (builds trust with agencies)
> A note for the agencies we work with: we know the lanes matter. Caprate provides the unit and coordinates the housing side. Your team keeps the wraparound services and the relationship with your client. We're not trying to be everything — we're trying to be the reliable housing piece so you can do what you do best.
>
> That clarity is why case managers keep coming back to us. If you'd like to add Caprate to your placement options, reach out: (410) 415-3142.

### Post E — Weekly availability nudge (professional version)
> Our Baltimore availability updates weekly. If you place clients with Housing Choice Vouchers or HUD-VASH and you'd like the current unit-by-unit list — with bedroom counts and voucher notes — send me a message and I'll get you on the list.
>
> Caprate Property Management · (410) 415-3142 · leasing@capratepropertymgmt.com

---

## 3. "Intro to a New Agency" Message (email or LinkedIn DM)

A short, warm, reusable intro for reaching out to a placement agency you haven't worked with yet. Personalize the bracketed parts.

> **Subject:** Voucher-friendly housing partner in Baltimore — [Agency Name]
>
> Hi [Name],
>
> I'm Terry Drake with Caprate Property Management. We provide renovated, voucher-friendly rental homes across Baltimore City, and we work directly with case managers and placing agencies like [Agency Name] to house clients quickly.
>
> The short version of what makes us easy to work with: we welcome HCV/Section 8 and HUD-VASH, we're responsive on RTA and inspections, and we keep clear role boundaries — we handle the housing, your team keeps the services and the client relationship.
>
> If it'd be helpful, I can send you our current availability list (updated weekly, with bedroom counts and voucher notes) so you have it on hand for clients who are searching. No obligation — just want to be a reliable option when you need one.
>
> Best,
> Terry Drake
> Caprate Property Management
> (410) 415-3142 · leasing@capratepropertymgmt.com

---

## Notes on using Track 1 well

- **Consistency beats volume.** One thoughtful LinkedIn post a week and a reliable weekly email do more than a burst of activity that fizzles.
- **Connect with the agency contacts already in your CRM** — the value of LinkedIn here is being visible to the specific people who refer clients.
- **Photos of renovated units** work on LinkedIn too; they make the "move-in-ready" claim real.
- **Keep role-boundary language front and center.** It's the thing that makes agencies trust you — it tells them you won't step on their client relationship.
- **Everything stays fair-housing-clean:** what you accept, not who should apply. On the professional channel this is easy to hold, since you're talking about partnership and process.

---

*Caprate Property Management · Baltimore City, MD · (410) 415-3142 · leasing@capratepropertymgmt.com · Equal Housing Opportunity*
