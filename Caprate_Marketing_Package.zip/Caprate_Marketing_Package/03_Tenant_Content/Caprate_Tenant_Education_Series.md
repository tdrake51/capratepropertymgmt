# Caprate — Tenant Education Series
### Six ready-to-publish posts that help voucher holders take the lead in their search

**How to use these:** Post one per week on the Caprate Facebook Page (and pin the series to a "Voucher Holder's Guide" highlight or the website resource page). Each is written to stand alone. Keep the friendly, plain voice — these build trust, produce better-prepared applicants, and get shared. Each ends with a soft Caprate contact line.

**Guardrail baked into all six:** they educate and empower, and always defer a person's *specific* situation to their caseworker or HABC. Caprate is the helpful guide, not the housing authority.

---

## Post 1 — Your Voucher Has a Clock. Here's How to Use the Time Well.

If you just got your Housing Choice Voucher, congratulations — that's the hard part done. But here's something a lot of people don't realize until the pressure's on: your voucher comes with a search window, usually around 90 days, to find a place and get it approved. That time goes faster than you'd think once inspections and paperwork are in the mix.

So use it well from day one:
- **Start looking immediately** — don't wait until you've "settled in" to the idea. The clock starts ticking when the voucher is issued.
- **Know your bedroom size.** Your voucher is approved for a specific number of bedrooms based on your household. Only look at units that match — a place that's the wrong size can't be approved.
- **If you're running low on time, ask.** Extensions are sometimes available, especially as a reasonable accommodation for a disability or other circumstances. Your caseworker or HABC can tell you what's possible in your situation.

The people who use their voucher successfully are usually the ones who move early and stay organized. You've got this — just don't let the clock run out while you're deciding.

*Looking for a voucher-friendly home in Baltimore? Caprate has renovated units ready now. Call or text (410) 415-3142.*

---

## Post 2 — What to Have Ready Before You Call About an Apartment

The right apartment can go fast. When you find one that fits, being ready to move *that day* is often what gets you the place over the next person. So before you start calling, get your folder together — paper or on your phone, whatever's easier.

Have these ready:
- **Your voucher paperwork** — the voucher itself and your Request for Tenancy Approval (RFTA) info.
- **Photo ID.**
- **Proof of income** if you have any earned income (pay stubs, benefit letters).
- **References** — a past landlord's name and number if you have one, or someone who can vouch for you.
- **Your bedroom size and any must-haves** written down, so you can quickly tell if a unit fits.

When you call, you can say plainly: "I have a Housing Choice Voucher for a [size] and I'm ready to move forward." A landlord who knows the program will take it from there. Being organized signals you're a serious, reliable tenant — and that matters.

*Caprate works with case managers and voucher holders every day, and we make the paperwork side smooth. (410) 415-3142.*

---

## Post 3 — Know Your Rights: In Baltimore, Landlords Can't Refuse Your Voucher

This is one every voucher holder in Baltimore should know: **it is against the law here for a landlord to turn you away just because you'd pay part of your rent with a voucher.** Baltimore City and the State of Maryland both ban what's called "source of income" discrimination. A landlord can't put "no vouchers" or "no Section 8" in an ad, and can't refuse you simply for how you pay.

A few things that follow from that:
- A landlord **can** still screen you — background, rental history, and so on — but they have to use the **same standard they use for everyone**, not a tougher one because you have a voucher.
- Watch out for landlords who say you must earn two or three times the *full* rent. With a voucher, your share is usually about 30% of your income — not the whole rent. That kind of inflated income requirement is being challenged as a way of getting around the law.
- If a landlord flatly refuses your voucher, that's not allowed. You can raise it with a fair-housing organization or ask your caseworker how to report it.

Knowing this puts you in a stronger position. You're not asking for a favor — you're a qualified tenant with a reliable source of rent.

*At Caprate, your voucher is genuinely welcome — no extra fees, no runaround. (410) 415-3142.*

---

## Post 4 — What the Inspection Checks For (and Why It's on Your Side)

Every unit rented with a voucher has to pass a health-and-safety inspection before you move in. If you've never been through it, the word "inspection" can sound intimidating — but it's actually there to protect *you*. It makes sure the place you're about to call home is safe and decent.

In plain terms, the inspection is checking that the basics work and the home is safe:
- Working heat, hot water, electricity, and plumbing.
- Windows and doors that lock and function.
- Smoke and carbon-monoxide detectors.
- No serious hazards — things like exposed wiring, major leaks, or peeling paint in older homes.
- Appliances and fixtures in working order.

You don't have to fix anything — that's on the landlord. If something doesn't pass, the landlord repairs it and it gets re-checked. A good landlord keeps units inspection-ready, so this step goes quickly. If a place feels unsafe or the landlord seems to be dragging their feet on repairs, that tells you something worth knowing before you sign.

*Caprate's units are renovated and move-in ready, so inspections go smoothly. (410) 415-3142.*

---

## Post 5 — Questions to Ask Before You Sign a Lease

Finding a place you like is exciting, but take a breath before you sign. You're starting a relationship that lasts a year or more, and a few good questions now save headaches later. A landlord worth renting from will answer these clearly and won't mind you asking.

Ask:
- **What's included in the rent?** Which utilities are on you, which aren't?
- **Who handles repairs, and how fast?** How do you reach them when something breaks?
- **What's the security deposit, and what would come out of it?** In Maryland you have rights about how deposits are handled and returned.
- **What's the lease term, and what happens when it ends?**
- **Is there anything about the unit I should know?** Give them a chance to be upfront.

Pay attention to *how* they answer as much as what they say. Clear, patient answers are a good sign. Vague or annoyed ones tell you how it'll feel to deal with them after you've moved in.

*We believe in straight answers before you sign. Ask us anything: (410) 415-3142.*

---

## Post 6 — How Your Rent Share Is Figured (the Money, Explained Simply)

One of the most common questions voucher holders have is the simplest to answer once someone explains it: **how much will I actually pay?**

Here's the basic idea. With a Housing Choice Voucher, you generally pay about **30% of your adjusted household income** toward rent and utilities. The housing authority pays the rest directly to the landlord. So your payment is tied to *your income*, not the full price of the unit.

A couple of things worth knowing:
- Your exact share is calculated by the housing authority based on your income and certain deductions — so the precise number is theirs to confirm, not the landlord's.
- If your income drops, you can report it and your share can be recalculated so you're not stuck paying more than you can afford. Don't sit on a change in income — report it.
- The unit's total rent still has to be reasonable for the area, which the housing authority checks.

Understanding this takes a lot of the fear out of the search. You're not on the hook for a whole market rent — you're responsible for your portion, and the program covers the gap.

*Questions about a specific unit's rent? We'll walk you through it. Caprate: (410) 415-3142. For your exact voucher amount, your caseworker or HABC is the best source.*

---

*Caprate Property Management · Baltimore City, MD · (410) 415-3142 · leasing@capratepropertymgmt.com · Equal Housing Opportunity*

*These posts are general information to help you navigate your search — for the details of your specific voucher and situation, your case manager or the Housing Authority of Baltimore City is always the best source.*
