# Caprate — Facebook Marketplace Listings

**Posting from Yudah Roseberg's profile, on behalf of Caprate Property Management.** Marketplace runs off personal profiles, so that's expected. Each unit below is ONE Marketplace listing (Marketplace requires one listing per unit).

## HOW TO POST EACH ONE
1. Facebook → Marketplace → **+ Create new listing** → **Home for Sale or Rent** (rental category — this applies Facebook's housing/anti-discrimination rules automatically).
2. Fill the fields shown for each unit below (Title, Rent/price, Beds, Baths, Property type, Location).
3. Add the photos from that unit's folder in the Facebook_Posts kit. Units marked **PHOTOS NEEDED** should wait for pics or use the branded graphic as a placeholder.
4. Paste the Description text.
5. Set location to the neighborhood/ZIP (you don't have to expose the exact street number if you'd rather not — Marketplace lets you show a general area).

> **⚠️ ALL RENTS BELOW ARE MARKET ESTIMATES — Terry to correct before posting.** They're anchored to Baltimore market data and your Triangle comps, not confirmed contract rents.

> **Fair housing:** every listing states what's accepted (vouchers), never who should apply. Keep it that way in replies/comments too. Facebook's rental category also restricts certain targeting automatically.

---

## 5110 Nelson Ave

**Listing Title:** 2BR/1BA Arlington — Voucher Friendly
**Rent (est. — verify):** $1800/mo
**Property type:** Apartment/Townhome · **Beds:** 2 · **Baths:** 1
**Location to enter:** Arlington, Baltimore, MD 21215

**Description (paste this):**

Fully renovated end-of-row rowhome. Stainless steel kitchen with granite counters, wood-look LVP floors throughout, finished basement with in-unit washer & dryer, separate dining area, private fenced rear yard. Move-in ready.

✅ Vouchers welcome — HCV / Section 8 / HUD-VASH accepted
✅ No extra fees for voucher holders
✅ We work directly with case managers for fast RTA processing

Managed by Caprate Property Management. To schedule a showing or refer a client, call (410) 415-3142 or email leasing@capratepropertymgmt.com.

---

## 4911 Nelson Ave  🚩 PHOTOS NEEDED

**Listing Title:** 2BR/1BA Arlington — Voucher Friendly
**Rent (est. — verify):** $1800/mo
**Property type:** Apartment/Townhome · **Beds:** 2 · **Baths:** 1
**Location to enter:** Arlington, Baltimore, MD 21215
**⚠️ Internal note (don't post):** Bed/bath from block comps — confirm

**Description (paste this):**

Renovated rowhome in Arlington. Voucher-friendly. Contact for full details and to schedule a tour.

✅ Vouchers welcome — HCV / Section 8 / HUD-VASH accepted
✅ No extra fees for voucher holders
✅ We work directly with case managers for fast RTA processing

Managed by Caprate Property Management. To schedule a showing or refer a client, call (410) 415-3142 or email leasing@capratepropertymgmt.com.

---

## 629 Dumbarton Ave, Unit D

**Listing Title:** 1BR/1BA Original Northwood — Voucher Friendly
**Rent (est. — verify):** $1200/mo
**Property type:** Apartment/Townhome · **Beds:** 1 · **Baths:** 1
**Location to enter:** Original Northwood, Baltimore, MD 21218
**⚠️ Internal note (don't post):** Bed count had a 1BR/3BR conflict — verify

**Description (paste this):**

Renovated 1-bedroom apartment in a quiet Northeast Baltimore building. Fresh finishes, convenient to the VA and major routes. Move-in ready.

✅ Vouchers welcome — HCV / Section 8 / HUD-VASH accepted
✅ No extra fees for voucher holders
✅ We work directly with case managers for fast RTA processing

Managed by Caprate Property Management. To schedule a showing or refer a client, call (410) 415-3142 or email leasing@capratepropertymgmt.com.

---

## 1922 Griffis Ave

**Listing Title:** 2BR/1BA Rosemont — Voucher Friendly
**Rent (est. — verify):** $1300/mo
**Property type:** Apartment/Townhome · **Beds:** 2 · **Baths:** 1
**Location to enter:** Rosemont, Baltimore, MD 21216

**Description (paste this):**

Renovated rowhome. Bright, clean finishes throughout. Move-in ready. Voucher-friendly.

✅ Vouchers welcome — HCV / Section 8 / HUD-VASH accepted
✅ No extra fees for voucher holders
✅ We work directly with case managers for fast RTA processing

Managed by Caprate Property Management. To schedule a showing or refer a client, call (410) 415-3142 or email leasing@capratepropertymgmt.com.

---

## 511 E 43rd St, Unit 3A

**Listing Title:** 3BR/1BA Waverly / Pen Lucy — Voucher Friendly
**Rent (est. — verify):** $1700/mo
**Property type:** Apartment/Townhome · **Beds:** 3 · **Baths:** 1
**Location to enter:** Waverly / Pen Lucy, Baltimore, MD 21212
**⚠️ Internal note (don't post):** Confirm 3A is 3BR (Triangle feed conflicted)

**Description (paste this):**

Spacious 3-bedroom apartment with in-unit washer & dryer. Near Loyola, Notre Dame & Johns Hopkins. Renovated and move-in ready.

✅ Vouchers welcome — HCV / Section 8 / HUD-VASH accepted
✅ No extra fees for voucher holders
✅ We work directly with case managers for fast RTA processing

Managed by Caprate Property Management. To schedule a showing or refer a client, call (410) 415-3142 or email leasing@capratepropertymgmt.com.

---

## 1700 Braddish Ave, Unit A

**Listing Title:** 1BR/1BA Rosemont — Voucher Friendly
**Rent (est. — verify):** $1150/mo
**Property type:** Apartment/Townhome · **Beds:** 1 · **Baths:** 1
**Location to enter:** Rosemont, Baltimore, MD 21216

**Description (paste this):**

Renovated 1-bedroom apartment with fresh finishes throughout. Voucher-friendly. Move-in ready.

✅ Vouchers welcome — HCV / Section 8 / HUD-VASH accepted
✅ No extra fees for voucher holders
✅ We work directly with case managers for fast RTA processing

Managed by Caprate Property Management. To schedule a showing or refer a client, call (410) 415-3142 or email leasing@capratepropertymgmt.com.

---

## 2513 Liberty Heights Ave, Basement

**Listing Title:** 1BR/1BA Forest Park — Voucher Friendly
**Rent (est. — verify):** $1100/mo
**Property type:** Apartment/Townhome · **Beds:** 1 · **Baths:** 1
**Location to enter:** Forest Park, Baltimore, MD 21215
**⚠️ Internal note (don't post):** Low-res photos on hand — reshoot recommended

**Description (paste this):**

Renovated basement apartment with private entrance in a multifamily building. Voucher-friendly. Move-in ready.

✅ Vouchers welcome — HCV / Section 8 / HUD-VASH accepted
✅ No extra fees for voucher holders
✅ We work directly with case managers for fast RTA processing

Managed by Caprate Property Management. To schedule a showing or refer a client, call (410) 415-3142 or email leasing@capratepropertymgmt.com.

---

## 724 N Edgewood St, Unit B  🚩 PHOTOS NEEDED

**Listing Title:** Edmondson Apartment — Voucher Friendly
**Rent (est. — verify):** $1100/mo
**Property type:** Apartment/Townhome · **Beds:** Contact · **Baths:** Contact
**Location to enter:** Edmondson, Baltimore, MD 21229
**⚠️ Internal note (don't post):** Bed/bath not resolved online — confirm

**Description (paste this):**

Voucher-friendly apartment in Southwest Baltimore. Contact for bed/bath details and to schedule a tour.

✅ Vouchers welcome — HCV / Section 8 / HUD-VASH accepted
✅ No extra fees for voucher holders
✅ We work directly with case managers for fast RTA processing

Managed by Caprate Property Management. To schedule a showing or refer a client, call (410) 415-3142 or email leasing@capratepropertymgmt.com.

---

## 2603 Boone St  🚩 PHOTOS NEEDED

**Listing Title:** 3BR/1BA Better Waverly — Voucher Friendly
**Rent (est. — verify):** $1900/mo
**Property type:** Apartment/Townhome · **Beds:** 3 · **Baths:** 1
**Location to enter:** Better Waverly, Baltimore, MD 21218
**⚠️ Internal note (don't post):** 3BR/1BA confirmed via records

**Description (paste this):**

Renovated 3-bedroom rowhome, ~1,200 sq ft, in Better Waverly. Move-in ready. Voucher-friendly.

✅ Vouchers welcome — HCV / Section 8 / HUD-VASH accepted
✅ No extra fees for voucher holders
✅ We work directly with case managers for fast RTA processing

Managed by Caprate Property Management. To schedule a showing or refer a client, call (410) 415-3142 or email leasing@capratepropertymgmt.com.

---

## 2905 Garrison Blvd, Unit C

**Listing Title:** 1BR/1BA Garwyn Oaks — Voucher Friendly
**Rent (est. — verify):** $1250/mo
**Property type:** Apartment/Townhome · **Beds:** 1 · **Baths:** 1
**Location to enter:** Garwyn Oaks, Baltimore, MD 21216
**⚠️ Internal note (don't post):** VERIFY photos are Unit C (folder said A); 1BR/2BR conflict

**Description (paste this):**

Renovated apartment with granite counters, stainless steel appliances, and on-site laundry. Voucher-friendly. Move-in ready.

✅ Vouchers welcome — HCV / Section 8 / HUD-VASH accepted
✅ No extra fees for voucher holders
✅ We work directly with case managers for fast RTA processing

Managed by Caprate Property Management. To schedule a showing or refer a client, call (410) 415-3142 or email leasing@capratepropertymgmt.com.

---

## 3512 Clifton Ave, Unit 3  🚩 PHOTOS NEEDED

**Listing Title:** Walbrook Apartment — Voucher Friendly
**Rent (est. — verify):** $1100/mo
**Property type:** Apartment/Townhome · **Beds:** Contact · **Baths:** Contact
**Location to enter:** Walbrook, Baltimore, MD 21216
**⚠️ Internal note (don't post):** Unit 3 config not resolved online — confirm

**Description (paste this):**

Voucher-friendly apartment in a renovated multi-unit building. Contact for bed/bath details and to tour.

✅ Vouchers welcome — HCV / Section 8 / HUD-VASH accepted
✅ No extra fees for voucher holders
✅ We work directly with case managers for fast RTA processing

Managed by Caprate Property Management. To schedule a showing or refer a client, call (410) 415-3142 or email leasing@capratepropertymgmt.com.

---

## 2910 Garrison Blvd, Unit 2T

**Listing Title:** 2BR/1BA Garwyn Oaks — Voucher Friendly
**Rent (est. — verify):** $1300/mo
**Property type:** Apartment/Townhome · **Beds:** 2 · **Baths:** 1
**Location to enter:** Garwyn Oaks, Baltimore, MD 21216

**Description (paste this):**

Renovated 2-bedroom apartment with in-unit washer & dryer and a granite & stainless kitchen. Voucher-friendly. Move-in ready.

✅ Vouchers welcome — HCV / Section 8 / HUD-VASH accepted
✅ No extra fees for voucher holders
✅ We work directly with case managers for fast RTA processing

Managed by Caprate Property Management. To schedule a showing or refer a client, call (410) 415-3142 or email leasing@capratepropertymgmt.com.

---

## 2910 Garrison Blvd, Unit 5T

**Listing Title:** 2BR/1BA Garwyn Oaks — Voucher Friendly
**Rent (est. — verify):** $1300/mo
**Property type:** Apartment/Townhome · **Beds:** 2 · **Baths:** 1
**Location to enter:** Garwyn Oaks, Baltimore, MD 21216

**Description (paste this):**

ACCESSIBLE 2-bedroom apartment — ramped entry, walk-in shower with grab bars. Renovated throughout. Voucher-friendly. Move-in ready.

✅ Vouchers welcome — HCV / Section 8 / HUD-VASH accepted
✅ No extra fees for voucher holders
✅ We work directly with case managers for fast RTA processing

Managed by Caprate Property Management. To schedule a showing or refer a client, call (410) 415-3142 or email leasing@capratepropertymgmt.com.

---

## 2924 Garrison Blvd, Unit B  🚩 PHOTOS NEEDED

**Listing Title:** Garwyn Oaks Apartment — Voucher Friendly
**Rent (est. — verify):** $1200/mo
**Property type:** Apartment/Townhome · **Beds:** Contact · **Baths:** Contact
**Location to enter:** Garwyn Oaks, Baltimore, MD 21216
**⚠️ Internal note (don't post):** 1-2BR cluster — confirm Unit B

**Description (paste this):**

Voucher-friendly apartment in the Garwyn Oaks community. Contact for bed/bath details and to schedule a tour.

✅ Vouchers welcome — HCV / Section 8 / HUD-VASH accepted
✅ No extra fees for voucher holders
✅ We work directly with case managers for fast RTA processing

Managed by Caprate Property Management. To schedule a showing or refer a client, call (410) 415-3142 or email leasing@capratepropertymgmt.com.

---

## 2945 Allendale Rd, Unit B  🚩 PHOTOS NEEDED

**Listing Title:** Garwyn Oaks Apartment — Voucher Friendly
**Rent (est. — verify):** $1200/mo
**Property type:** Apartment/Townhome · **Beds:** Contact · **Baths:** Contact
**Location to enter:** Garwyn Oaks, Baltimore, MD 21216
**⚠️ Internal note (don't post):** 1-2BR cluster — confirm Unit B

**Description (paste this):**

Voucher-friendly apartment in the Garwyn Oaks community. Contact for bed/bath details and to schedule a tour.

✅ Vouchers welcome — HCV / Section 8 / HUD-VASH accepted
✅ No extra fees for voucher holders
✅ We work directly with case managers for fast RTA processing

Managed by Caprate Property Management. To schedule a showing or refer a client, call (410) 415-3142 or email leasing@capratepropertymgmt.com.

---

## 2933 Allendale Rd, Unit T  🚩 PHOTOS NEEDED

**Listing Title:** 2BR/1BA Garwyn Oaks — Voucher Friendly
**Rent (est. — verify):** $1300/mo
**Property type:** Apartment/Townhome · **Beds:** 2 · **Baths:** 1
**Location to enter:** Garwyn Oaks, Baltimore, MD 21216
**⚠️ Internal note (don't post):** 2BR/1BA confirmed via archive; needs photos

**Description (paste this):**

Renovated 2-bedroom apartment with on-site laundry & parking. Voucher-friendly. Move-in ready.

✅ Vouchers welcome — HCV / Section 8 / HUD-VASH accepted
✅ No extra fees for voucher holders
✅ We work directly with case managers for fast RTA processing

Managed by Caprate Property Management. To schedule a showing or refer a client, call (410) 415-3142 or email leasing@capratepropertymgmt.com.

---
