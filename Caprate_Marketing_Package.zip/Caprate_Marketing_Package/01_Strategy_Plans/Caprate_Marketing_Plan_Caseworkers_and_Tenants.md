# Caprate — Online Marketing Plan: Reaching Caseworkers & Empowering Tenants
### Two audiences, two playbooks · Baltimore City · 2026

---

## Why two separate playbooks

Caprate's tenants arrive through two very different doors, and they behave nothing alike online:

- **Caseworkers & housing navigators** are professionals doing a job. They're on LinkedIn and email, they check whether you're legitimate before referring a client, and they value reliability over marketing polish. You reach them through **credibility and consistency**, not ads.

- **Individual voucher holders** are people under real pressure — often a 90-day voucher clock ticking, limited transportation, and a process nobody fully explained to them. They're on **Facebook, their phones, and Google**, and what they need most isn't a sales pitch — it's **clarity and confidence.** Teach them how the process works and where to find you, and you become the landlord they trust.

This plan runs both tracks in parallel. Track 1 makes Caprate the operator caseworkers *refer to*. Track 2 makes Caprate the landlord tenants *find and trust* — partly by helping them take the lead in their own search.

---

# TRACK 1 — Reaching Caseworkers Online

Caseworkers rarely respond to advertising. They respond to a partner who makes their job easier and who checks out when they look you up. The online work here is about **being findable, credible, and easy to refer to.**

### 1. Be searchable and legitimate
When a caseworker hears "Caprate," the first thing they do is search you. Make sure they find:
- A live, professional **website** (already built) that speaks directly to case managers — the "For Case Managers" section is the one that matters here.
- An active **Facebook Page** with recent posts, so you look like a going concern, not a dead listing.
- Consistent name, phone, and email everywhere. Mismatched contact info reads as unprofessional or worse.

### 2. A dedicated caseworker-facing web page or section
Give agencies a single link you can drop in an email that answers their questions before they ask:
- What Caprate provides vs. what the agency keeps (clear role boundaries — this is what makes you safe to refer to).
- How fast RTA and inspections move.
- Current availability, or how to request the weekly list.
- One point of contact.

### 3. LinkedIn presence (the professional channel)
Caseworkers, housing navigators, and agency staff are on LinkedIn. A simple, active Caprate/Terry Drake presence — occasional posts about available units, voucher-friendly commitment, and placement partnerships — keeps you visible to the professionals who send referrals. This is low-effort, high-credibility. Connect with the agency contacts already in your CRM.

### 4. The weekly availability email (your workhorse)
This already exists and it's the single most effective caseworker touch. Keep it disciplined:
- Same day each week, unit-by-unit list with bed/bath and voucher notes.
- BCC the distribution list; attach the current flyer.
- Framed around partnership ("here's what's open for your clients"), never vacancy-filling.

### 5. Email nurture, not blast
Between weekly lists, occasionally send agency contacts something genuinely useful — a note when an accessible unit opens, a heads-up on a unit that fits a client profile they mentioned. This is CRM-driven relationship work, and it's what turns a cold agency into a pipeline.

### 6. Make referring frictionless
Give caseworkers an easy path: a short referral form, a direct number, or a simple "text me the client's voucher size and I'll tell you what fits." The less work it takes to refer, the more referrals you get.

---

# TRACK 2 — Empowering the Individual (and Getting Found)

This track does two jobs at once: **help voucher holders take the lead in their own search**, and **make sure they find Caprate when they do.** The education *is* the marketing — teaching someone how the process works, from the landlord who's clearly on their side, builds trust nothing else can buy.

### Part A — Help the individual take the lead

Most voucher holders were never taught how the search actually works. Content that walks them through it — in plain, friendly language — positions Caprate as the helpful expert *and* produces better-prepared applicants. Publish this as short Facebook posts, a website resource page, and simple graphics.

**Topics that genuinely help (and quietly market):**
- **"Your voucher has a clock — here's how to use the time well."** How the ~90-day search window works and why moving fast matters.
- **"What to have ready before you call about an apartment."** ID, voucher paperwork, references — so they can move the moment they find a fit.
- **"Know your rights: landlords can't refuse your voucher in Baltimore."** The source-of-income law, in plain terms. Empowering *and* it reinforces exactly why Caprate is different.
- **"What the inspection checks for — and why it protects you."** Demystifies HQS so it's not scary.
- **"Questions to ask before you sign."** Turns a nervous applicant into a confident one.
- **"How your rent share is figured."** The ~30%-of-income basics, so they understand the money.

> **Guardrail:** Caprate educates and empowers — it does not give official housing-authority determinations or legal advice. Always point people to their own case manager or HABC for their specific situation. "Here's generally how it works, and your caseworker can confirm your details" is the right note. This keeps you helpful without overstepping.

**Format for reach:** short, warm, one-topic-at-a-time posts and simple branded graphics. A "Voucher Holder's Guide" resource page on the website that all these posts link back to. The blog post already written is the anchor piece.

### Part B — Make sure they discover the listings

Empowered tenants still have to *find* you. Meet them where they actually look:

**AffordableHousing.com** — HABC's official free listing partner and where voucher holders (and their caseworkers) search first. Every unit belongs here with photos. This is the highest-yield discovery channel for your exact tenant, and it's free.

**Facebook — Page, Marketplace, and Groups.** Voucher holders are active here. Post the per-unit kits (photos + captions already built). Marketplace listings (drafted) put you in front of local searchers. **Local Baltimore housing and voucher-holder Facebook Groups** are especially high-intent — people literally post "looking for a Section 8 friendly 2BR." Being present and responsive there is free and direct. (Follow each group's posting rules.)

**Google-findability.** When someone searches "Section 8 friendly apartments Baltimore" or "voucher accepted [neighborhood]," Caprate should surface. The website with clear voucher-welcome language, a Google Business Profile, and listings on the platforms above all feed this. A Google Business Profile is free and helps you appear in local searches and maps.

**Word of mouth is huge in this community.** Voucher holders share leads with each other constantly. Every tenant you treat well, every person you help understand the process, becomes a referral source. This is why the "empower the individual" content pays off twice — it markets to the person reading it *and* to everyone they tell.

### Part C — Make first contact easy and human
An empowered tenant who finds you needs an easy, non-intimidating way to reach out:
- A phone number they can call or text.
- A short inquiry form that doesn't demand everything up front.
- Fast, warm responses. Someone navigating a voucher search has often been turned away or ignored elsewhere — being genuinely responsive is a differentiator by itself.

---

## How the two tracks feed each other

The tracks aren't separate silos — they reinforce:
- A tenant who learns the process from your content becomes a **better-prepared applicant**, which makes the **caseworker's** job easier and makes Caprate easier to refer to.
- A caseworker who trusts you sends clients who **already know Caprate's name** from Facebook.
- Strong, findable listings serve **both** — the caseworker checking availability and the individual searching directly land on the same professional presence.

---

## Priority order (what to do first)

1. **AffordableHousing.com listings** for all photo-ready units — free, highest-yield for both audiences.
2. **Keep the weekly caseworker email + agency outreach** running — your proven channel.
3. **Publish the tenant-education content** (blog + short posts) — builds trust and better applicants.
4. **Facebook Page + Marketplace + Groups** — where individuals discover you.
5. **Google Business Profile + LinkedIn** — findability for both audiences, low effort.
6. **Finish the photo run** — gates the effectiveness of everything above.

---

## Honest cautions

**The education content must stay in its lane.** Empower and inform; never position Caprate as giving official HABC determinations or legal advice. Always defer specifics to the person's caseworker or HABC. This protects the tenant *and* Caprate.

**Fair housing on every public post.** State what you accept, not who should apply. This applies doubly to the tenant-facing content — keep it about the process and the units, welcoming to everyone.

**Responsiveness is the whole thing.** All this drives inquiries; if inquiries sit unanswered, the plan fails. The empowered-tenant strategy especially depends on Caprate being the one who actually calls back.

**Word of mouth cuts both ways.** In a tight-knit voucher community, reputation travels fast — good and bad. Every interaction is marketing.

---

## The takeaway

Reach caseworkers through **credibility and consistency** — be findable, legitimate, and effortless to refer to. Reach individuals through **empowerment and presence** — teach them how to take the lead in their own search, then make sure Caprate is easy to find and easy to contact when they do. The education you give the tenant is also the trust you build with the caseworker. Run both tracks, keep it fair-housing-clean, and answer every inquiry like it matters — because in this community, it does.

---

*Caprate Property Management · Baltimore City, MD · (410) 415-3142 · leasing@capratepropertymgmt.com · Equal Housing Opportunity*
