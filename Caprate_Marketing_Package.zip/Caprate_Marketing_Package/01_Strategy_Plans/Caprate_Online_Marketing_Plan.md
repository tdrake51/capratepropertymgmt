# Caprate Property Management — Online Marketing & Tenant-Sourcing Plan
### Baltimore City · Voucher-Friendly Rentals · 2026

---

## The short version

Caprate has ~16 available units and a clear niche: renovated, voucher-friendly homes across Northwest, Northeast, and Central Baltimore, backed by a real relationship with the case managers who place tenants. This plan uses that niche deliberately. It treats online marketing (Marketplace, Facebook, listing sites, the website) as the **top of the funnel that fills vacancies from the general public**, and the **agency/caseworker network as the bottom of the funnel that delivers pre-qualified, voucher-ready tenants**. The two feed each other.

The goal isn't "more eyeballs." It's **filling units with qualified voucher and market tenants, fast, at the lowest cost per lease.** For voucher-friendly housing in Baltimore, the highest-yield channel is almost always the caseworker relationship — so online works hardest when it makes Caprate look established and trustworthy to *both* tenants and the agencies watching.

---

## What we know (the facts this plan is built on)

**The market:** Baltimore rents are stable-to-soft in 2026 — roughly $1,300–$1,780 for a 1BR, $1,650–$2,150 for a 2BR, $1,900+ for a 3BR citywide, with enormous neighborhood variation (sub-$1,000 1BRs exist in Allendale/Edmondson; $2,000+ in Canton/Federal Hill). A cooling market means **more tenant negotiating power and more competition among landlords** — so standing out matters.

**The niche is a legal tailwind:** Baltimore City and Maryland both ban source-of-income discrimination. Most landlords still quietly avoid vouchers because of the paperwork and inspections. That reluctance is Caprate's opening — being genuinely voucher-fluent and case-manager-friendly is a real, defensible differentiator, not just a slogan.

**Where voucher tenants actually come from:** HABC disperses 18,000+ vouchers. Voucher holders find units through (1) their case managers and housing navigators, (2) AffordableHousing.com (HABC's free official listing partner), and (3) general search. The tenant-based waitlist is closed, but vouchers are actively being issued and ported in — the demand is real and ongoing.

**What Caprate already has built** (assets this plan deploys): a portfolio/CRM system, an agency contact network across housing/recovery/behavioral-health providers, a branded flyer, per-unit social post kits with photos, a website landing page, a tenant-education blog post, and Marketplace listings drafted.

---

## The strategy: four channels, one funnel

### Channel 1 — AffordableHousing.com (the one you can't skip)
This is HABC's official free listing platform, and it's where voucher holders and their caseworkers look first. It's free, it's voucher-specific, and it filters for exactly your tenant.

**Do this:** List every available unit here with photos, correct bed/bath, and the voucher-welcome note. This is the single highest-ROI online action for voucher-friendly units — it's free and the audience is pre-qualified. Treat it as the baseline, not an afterthought.

### Channel 2 — The agency/caseworker network (your competitive moat)
This is Caprate's real edge and it's mostly *not* "online" — it's relationship work, supported by digital assets. The weekly availability flyer, the drop-in visits, the CRM follow-ups. Online marketing makes this channel stronger by making Caprate look legitimate when a caseworker Googles you.

**Do this:**
- Keep the **weekly flyer email** going to the full agency distribution list (the one already built).
- Continue the **drop-in and call-first outreach** on the routes already mapped.
- When a caseworker checks you out, they should find a real website, active Facebook page, and professional listings. That's the online job here: *credibility for the referral channel.*

### Channel 3 — Facebook (Page + Marketplace + Groups)
Facebook is where Baltimore renters and community members actually are, and it's free.

**Business Page:** Post the per-unit kits (photos + branded graphics + captions already built). Cadence: 3–4 posts/week — mix available units, the occasional tenant-education post (the blog), and voucher-welcome messaging. Photos always beat graphics; lead with real interior shots.

**Marketplace:** The listings are drafted (posting from Yudah's profile on behalf of Caprate). One listing per unit, "Home for Sale or Rent" category. Lead with photo-ready units; post in batches over several days to avoid spam flags.

**Local Facebook Groups:** Baltimore housing, neighborhood, and voucher-holder groups are high-intent and free. Share available units where group rules allow. (Read each group's rules — many require you post only in designated threads.)

### Channel 4 — Paid listing sites (selective, only where they earn it)
Zillow/Trulia/Apartments.com/Hotpads reach the general market and some voucher holders who search there. These cost money and are worth it mainly for your **market-rate or higher-rent units** (the 3BRs, the nicer 2BRs) where the broader audience matters. For deeply voucher-targeted units, AffordableHousing.com + agencies will usually outperform paid sites at zero cost.

**Do this:** Be selective. Put your best-photographed, higher-rent units on one paid syndicator; keep the voucher-heavy units on the free voucher-specific channels.

---

## Sequencing: what to do, in what order

**Phase 1 — Foundation (Week 1)**
Get the free, high-yield channels live before spending a dollar.
- List all photo-ready units on **AffordableHousing.com**.
- Post the **photo-ready units** to the Facebook Page and to Marketplace (batched).
- Confirm the website is live and listings/contact route correctly.
- Keep the weekly agency flyer going.

**Phase 2 — Fill the gaps (Weeks 2–3)**
- Complete the **photo run** for the 7 units without pictures (route already mapped) so every unit is postable.
- Resolve the flagged unknowns (2905 Garrison C photos/beds, Dumbarton bed count, 511 E 43rd config).
- Add tenant-education content (the blog post) to the Page to build follow and trust.

**Phase 3 — Amplify & measure (Week 4+)**
- Add selective paid listings for higher-rent units.
- Expand agency outreach to new placement partners.
- Track what's actually working (see metrics below) and shift effort toward the channels producing leases.

---

## Messaging that works for this audience

**Lead with what you accept, never who should apply.** "Vouchers welcome — HCV/Section 8/HUD-VASH accepted" is legal, clear, and exactly your differentiator. This holds on every channel, and it's a fair-housing requirement, not just a style choice.

**Three things to say everywhere:**
1. Vouchers genuinely welcome — no extra fees, no runaround.
2. Renovated, move-in-ready — not a project that stalls at inspection.
3. We work directly with case managers — fast RTA.

**For the caseworker audience specifically:** emphasize responsiveness, RTA speed, and clear role boundaries (Caprate provides the unit and coordinates; the agency keeps the wraparound services). That's what makes you easy to refer to.

**Photos are the whole game.** Bright, renovated interior photos outperform everything else. Kitchen and bathroom shots sell. A unit without photos will underperform on every channel — which is why finishing the photo run is Phase 2's priority.

---

## What to measure (so effort follows results)

Keep it simple. For each channel, track:
- **Inquiries per unit per week** — which channel actually generates contacts.
- **Showings booked** — inquiries that turn into real interest.
- **Leases signed + source** — the only number that ultimately matters. Ask every applicant "how did you hear about us?" and log it in the CRM.
- **Time-to-lease per unit** — how long a vacancy sits.
- **Cost per lease** — free channels (AffordableHousing, agencies, Facebook) vs. paid sites.

After 30–60 days you'll see the pattern clearly, and for voucher-friendly Baltimore units it will almost certainly show **agencies + AffordableHousing.com deliver the most qualified leases at the lowest cost** — at which point you lean in there and treat paid sites as a supplement.

---

## Honest cautions

**Don't over-invest in paid listing sites up front.** For voucher-heavy inventory, the free voucher-specific and agency channels usually win. Spend there only after you see them earning leases.

**Photos gate everything.** Half the plan's effectiveness depends on finishing the photo run. Units without pictures should be de-prioritized in posting order, not pushed with placeholders that generate low-quality inquiries.

**Fair housing is non-negotiable on every public channel.** Facebook's rental category enforces some of this automatically, but the copy discipline (what you accept, not who should apply; no targeting by protected class) is on you. The materials already built follow this — keep it up in replies and comments too.

**Marketplace volume caution.** Posting 16 listings at once from one personal profile can trip spam detection. Batch them.

**This is a plan, not a guarantee.** A cooling market means units may take longer to fill than in hot years. Conservative expectation: lead with your strengths (agencies + free voucher channels + strong photos), measure honestly, and adjust.

---

## The one-paragraph takeaway

Caprate's marketing advantage in Baltimore isn't outspending anyone online — it's being the genuinely voucher-friendly, caseworker-trusted operator in a market where most landlords quietly avoid vouchers. So the plan is: make the free, voucher-specific channels (AffordableHousing.com, the agency network, Facebook) do the heavy lifting; use strong renovated-interior photos everywhere; keep the website and Page polished so referrals trust what they find; and add paid listings only for the higher-rent units where the broader market matters. Measure leases by source, and pour effort into whatever's actually producing them.

---

*Caprate Property Management · Baltimore City, MD · (410) 415-3142 · leasing@capratepropertymgmt.com · Equal Housing Opportunity*
